# Plan: Majlisync Teaser Page — Figma-to-Code Slicing

## Context

The user has finalized a Figma design (provided as generated React code in `src/imports/Dekstop/index.tsx`) for Majlisync's "coming soon" teaser page. The goal is to implement this design faithfully as a production-ready, fully responsive React + Tailwind component in the live app (`src/app/App.tsx`), deployable across desktop, tablet, and mobile. The CTA button must use `mailto:m.maatouk@majlisync.com`.

---

## Design Tokens (from desain.md + Figma component)

| Token | Value |
|---|---|
| Background | `#0A0F16` |
| Accent Cyan (CTA bg) | `#4FD1E5` |
| Accent Cyan (link/TLS) | `#36BFD4` |
| Success/Active Green | `#22C55E` |
| Warning Amber | `#F59E0B` |
| Text Primary | `#FFFFFF` |
| Text Secondary | `#EAEAEA` |

Typography:
- Logo: Inter ExtraBold 32px
- Headline: Inter ExtraBold 54px (desktop) → 36px (tablet) → 26px (mobile)
- Body: Inter Medium 16px, line-height 26px
- Mono status: JetBrains Mono Regular 12px
- CTA: Inter SemiBold 14px, letter-spacing 1.4px, UPPERCASE

---

## Files to Create / Modify

### 1. `src/styles/fonts.css`
Add Google Fonts imports at the top for Inter (weights 500, 600, 800) and JetBrains Mono (weight 400). This file is currently empty.

### 2. `src/app/components/majlisync-teaser.tsx` _(new file)_
Responsive faithful implementation of the Figma design. Sub-components:

- **`GridOverlay`** — 12 vertical white lines at 4% opacity, absolutely positioned and full-width. Implemented as a responsive SVG that fills 100vw × 100vh.
- **`StatusBar`** — green pulsing dot + monospace "System Initialization: Deployment in Progress." — top center, full width.
- **`BrandLogo`** — "Majlisync" in Inter ExtraBold with a cyan `#4FD1E5` horizontal rule beneath it (80px wide centered).
- **`HeroHeadline`** — "SOVEREIGN DECISION INFRASTRUCTURE" in Inter ExtraBold, responsive font size.
- **`HeroDescription`** — Body copy in Inter Medium at 16px, centered, max-width constrained.
- **`CTAButton`** — `<a href="mailto:m.maatouk@majlisync.com">` with cyan background, dark text, rounded-[4px], uppercase tracking. This replaces the incorrect `https://` href.
- **`TelemetryFooter`** — Three status items separated by vertical dividers: `Encrypted Connection: TLS 1.3` | `Sovereign Node: Active` | `Latency: 32ms`, all in JetBrains Mono 12px.
- **`MajlisyncTeaser`** (default export) — Assembles all above in a full-viewport flex column layout.

### 3. `src/app/App.tsx`
Replace the empty placeholder with an import and render of `MajlisyncTeaser`.

---

## Responsive Breakpoints (from desain.md)

| Breakpoint | Width | Key changes |
|---|---|---|
| Mobile | < 768px (default) | Headline ~26px, status bar stacks, padding reduced |
| Tablet | md: 768px+ | Headline ~36px, wider container |
| Desktop | lg: 1024px+ | Headline 54px, max-width 744px center column, grid at full 1440px |

Use Tailwind v4 responsive prefixes: `md:` and `lg:`.

---

## CTA Mailto Fix

In the Figma-generated code, the href is incorrectly `"https://m.maatouk@majlisync.com"`.  
The correct value is: `"mailto:m.maatouk@majlisync.com"`

---

## Grid Implementation

The Figma design uses 13 evenly-spaced vertical lines across 1400px. In the responsive version:
- Use a CSS approach: `background-image: repeating-linear-gradient(...)` or an SVG with `viewBox` and `preserveAspectRatio="none"` that scales to 100% viewport.
- 12 columns = lines at every ~8.33% of width (matching the 12-column grid from desain.md).

---

## Verification

1. Preview renders on desktop: headline at 54px, cyan CTA button visible, grid lines visible.
2. Resize to tablet (768px): headline scales down, layout still centered.
3. Resize to mobile (375px): readable, no horizontal overflow, CTA still tappable.
4. Click CTA: opens mail client addressed to `m.maatouk@majlisync.com`.
5. Status indicators visible: green dot, TLS cyan, Latency amber.
6. No horizontal scrollbar at any breakpoint.
