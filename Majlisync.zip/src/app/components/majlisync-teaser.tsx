import { useEffect, useState } from "react";

function GridOverlay() {
  return (
    <div className="absolute inset-0 w-full h-full overflow-hidden pointer-events-none" aria-hidden="true">
      <svg
        className="absolute inset-0 w-full h-full"
        fill="none"
        preserveAspectRatio="none"
        viewBox="0 0 1440 1024"
        xmlns="http://www.w3.org/2000/svg"
      >
        {Array.from({ length: 13 }, (_, i) => {
          const x = (i / 12) * 1440;
          return (
            <line
              key={i}
              x1={x}
              x2={x}
              y1="0"
              y2="1024"
              stroke="white"
              strokeOpacity="0.04"
            />
          );
        })}
      </svg>
    </div>
  );
}

function PulseDot() {
  return (
    <span className="relative flex h-[17px] w-[17px] shrink-0">
      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#22c55e] opacity-40" />
      <span className="relative inline-flex rounded-full h-[17px] w-[17px] bg-[#22c55e]" />
    </span>
  );
}

function StatusBar() {
  return (
    <div className="flex items-center justify-center gap-[6px] w-full max-w-[374px]">
      <PulseDot />
      <span
        className="text-[#22c55e] text-[12px] leading-normal"
        style={{ fontFamily: "'JetBrains Mono', monospace", fontWeight: 400 }}
      >
        System Initialization: Deployment in Progress.
      </span>
    </div>
  );
}

function BrandLogo() {
  return (
    <div className="flex flex-col items-center gap-[10px]">
      <span
        className="text-white text-[32px] leading-normal text-center"
        style={{ fontFamily: "'Inter', sans-serif", fontWeight: 800 }}
      >
        Majlisync
      </span>
      <div className="w-[80px] h-px bg-[#4fd1e5]" />
    </div>
  );
}

function HeroSection() {
  return (
    <div className="flex flex-col items-start w-full">
      <div className="w-full">
        <h1
          className="text-white text-center leading-tight w-full"
          style={{
            fontFamily: "'Inter', sans-serif",
            fontWeight: 800,
            fontSize: "clamp(26px, 4.5vw, 54px)",
          }}
        >
          SOVEREIGN DECISION INFRASTRUCTURE
        </h1>
      </div>
      <div className="w-full flex items-center justify-center">
        <p
          className="text-white text-center leading-[26px] pt-[20px] pb-[60px] px-[20px]"
          style={{
            fontFamily: "'Inter', sans-serif",
            fontWeight: 500,
            fontSize: "16px",
            maxWidth: "620px",
          }}
        >
          Empowering governments and enterprises with multi-agent cognitive
          governance. The platform is currently undergoing final deployment and
          will be launching soon.
        </p>
      </div>
    </div>
  );
}

function CTAButton() {
  return (
    <div className="flex flex-col items-center w-full">
      <a
        href="mailto:m.maatouk@majlisync.com"
        className="inline-flex items-center justify-center bg-[#4fd1e5] px-[24px] py-[12px] rounded-[4px] cursor-pointer transition-opacity hover:opacity-90 active:opacity-80"
        style={{ textDecoration: "none" }}
      >
        <span
          className="text-[#0a0f16] text-[14px] leading-[20px] tracking-[1.4px] uppercase whitespace-nowrap"
          style={{ fontFamily: "'Inter', sans-serif", fontWeight: 600 }}
        >
          CONTACT EXECUTIVE OFFICE →
        </span>
      </a>
    </div>
  );
}

function VerticalDivider() {
  return (
    <div className="flex h-[16px] items-center justify-center w-px">
      <div className="h-[16px] w-px bg-white opacity-50" />
    </div>
  );
}

function TelemetryFooter() {
  return (
    <div
      className="flex flex-wrap items-center justify-center gap-x-[10px] gap-y-[6px] w-full"
      style={{ fontFamily: "'JetBrains Mono', monospace", fontWeight: 400, fontSize: "12px" }}
    >
      <span className="text-[#eaeaea] whitespace-nowrap">
        Encrypted Connection:{" "}
        <span className="text-[#36bfd4]">TLS 1.3</span>
      </span>
      <VerticalDivider />
      <span className="text-[#eaeaea] whitespace-nowrap">
        Sovereign Node:{" "}
        <span className="text-[#22c55e]">Active</span>
      </span>
      <VerticalDivider />
      <span className="text-white whitespace-nowrap">
        Latency:{" "}
        <span className="text-[#f59e0b]">32ms</span>
      </span>
    </div>
  );
}

export function MajlisyncTeaser() {
  return (
    <div
      className="relative w-full min-h-screen flex flex-col items-center justify-between py-[10px] overflow-hidden"
      style={{ backgroundColor: "#0a0f16" }}
    >
      <GridOverlay />

      {/* Top: Status Bar */}
      <div className="relative z-10 flex items-center justify-center w-full pt-[4px]">
        <StatusBar />
      </div>

      {/* Center: Brand + Hero + CTA */}
      <div className="relative z-10 flex flex-col items-center gap-[30px] w-full px-4">
        <BrandLogo />
        <div className="flex flex-col items-center w-full max-w-[744px]">
          <HeroSection />
          <CTAButton />
        </div>
      </div>

      {/* Bottom: Telemetry */}
      <div className="relative z-10 w-full px-4 pb-[4px]">
        <TelemetryFooter />
      </div>
    </div>
  );
}

export default MajlisyncTeaser;
