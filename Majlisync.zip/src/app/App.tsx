import { MajlisyncTeaser } from "./components/majlisync-teaser";

export default function App() {
  return <MajlisyncTeaser />;
}
