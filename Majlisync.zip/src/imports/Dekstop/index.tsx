function Group() {
  return (
    <div className="absolute h-[1024px] left-[20px] top-0 w-[1400px]">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 1401 1024">
        <g id="Group 1">
          <line id="Line 2" stroke="var(--stroke-0, white)" strokeOpacity="0.04" x1="1400.5" x2="1400.5" y1="1024" y2="2.19181e-08" />
          <line id="Line 3" stroke="var(--stroke-0, white)" strokeOpacity="0.04" x1="1283.83" x2="1283.83" y1="1024" y2="2.19181e-08" />
          <line id="Line 4" stroke="var(--stroke-0, white)" strokeOpacity="0.04" x1="1167.17" x2="1167.17" y1="1024" y2="2.19181e-08" />
          <line id="Line 5" stroke="var(--stroke-0, white)" strokeOpacity="0.04" x1="1050.5" x2="1050.5" y1="1024" y2="2.19181e-08" />
          <line id="Line 6" stroke="var(--stroke-0, white)" strokeOpacity="0.04" x1="933.833" x2="933.833" y1="1024" y2="2.19181e-08" />
          <line id="Line 7" stroke="var(--stroke-0, white)" strokeOpacity="0.04" x1="817.167" x2="817.167" y1="1024" y2="2.19181e-08" />
          <line id="Line 8" stroke="var(--stroke-0, white)" strokeOpacity="0.04" x1="700.5" x2="700.5" y1="1024" y2="2.19181e-08" />
          <line id="Line 9" stroke="var(--stroke-0, white)" strokeOpacity="0.04" x1="583.833" x2="583.833" y1="1024" y2="2.19181e-08" />
          <line id="Line 10" stroke="var(--stroke-0, white)" strokeOpacity="0.04" x1="467.166" x2="467.166" y1="1024" y2="2.19181e-08" />
          <line id="Line 11" stroke="var(--stroke-0, white)" strokeOpacity="0.04" x1="350.5" x2="350.5" y1="1024" y2="2.19181e-08" />
          <line id="Line 12" stroke="var(--stroke-0, white)" strokeOpacity="0.04" x1="233.834" x2="233.834" y1="1024" y2="2.19181e-08" />
          <line id="Line 13" stroke="var(--stroke-0, white)" strokeOpacity="0.04" x1="117.166" x2="117.166" y1="1024" y2="2.19181e-08" />
          <line id="Line 14" stroke="var(--stroke-0, white)" strokeOpacity="0.04" x1="0.500045" x2="0.5" y1="1024" y2="2.18557e-08" />
        </g>
      </svg>
    </div>
  );
}

function Frame5() {
  return (
    <div className="relative shrink-0 size-[17px]">
      <svg className="absolute block inset-0 size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 17 17">
        <g id="Frame 154">
          <circle cx="8.5" cy="8.5" fill="var(--fill-0, #22C55E)" id="Ellipse 1" r="8.5" />
        </g>
      </svg>
    </div>
  );
}

function Frame3() {
  return (
    <div className="content-stretch flex flex-[1_0_0] items-center min-w-px relative">
      <div className="[word-break:break-word] flex flex-[1_0_0] flex-col font-['JetBrains_Mono:Regular',sans-serif] font-normal justify-center leading-[0] min-w-px relative text-[#22c55e] text-[12px]">
        <p className="leading-[normal]">System Initialization: Deployment in Progress.</p>
      </div>
    </div>
  );
}

function Frame7() {
  return (
    <div className="content-center flex flex-[1_0_0] flex-wrap gap-[6px] items-center justify-center min-w-px relative">
      <Frame5 />
      <Frame3 />
    </div>
  );
}

function Frame10() {
  return (
    <div className="content-stretch flex items-center justify-center relative shrink-0 w-[156px]">
      <p className="[word-break:break-word] flex-[1_0_0] font-['Inter:Extra_Bold',sans-serif] font-extrabold leading-[normal] min-w-px not-italic relative text-[32px] text-center text-white">Majlisync</p>
    </div>
  );
}

function Frame() {
  return (
    <div className="content-center flex flex-wrap gap-[10px] items-center justify-center relative shrink-0 w-[156px]">
      <Frame10 />
      <div className="h-0 relative shrink-0 w-[80px]">
        <div className="absolute inset-[-1px_0_0_0]">
          <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 80 1">
            <line id="Line 28" stroke="var(--stroke-0, #4FD1E5)" x2="80" y1="0.5" y2="0.5" />
          </svg>
        </div>
      </div>
    </div>
  );
}

function Frame6() {
  return (
    <div className="content-start flex flex-wrap gap-y-[10px] items-start justify-center relative shrink-0 w-full">
      <p className="[word-break:break-word] flex-[1_0_0] font-['Inter:Extra_Bold',sans-serif] font-extrabold leading-[normal] min-w-px not-italic relative text-[54px] text-center text-white">SOVEREIGN DECISION INFRASTRUCTURE</p>
    </div>
  );
}

function Frame8() {
  return (
    <div className="relative shrink-0 w-full">
      <div className="flex flex-row items-center justify-center size-full">
        <div className="content-center flex flex-wrap gap-y-[10px] items-center justify-center pb-[60px] pt-[20px] px-[20px] relative size-full">
          <p className="[word-break:break-word] flex-[1_0_0] font-['Inter:Medium',sans-serif] font-medium leading-[26px] min-w-px not-italic relative text-[16px] text-center text-white">Empowering governments and enterprises with multi-agent cognitive governance. The platform is currently undergoing final deployment and will be launching soon.</p>
        </div>
      </div>
    </div>
  );
}

function Frame9() {
  return (
    <div className="content-stretch flex flex-col items-start relative shrink-0 w-full">
      <Frame6 />
      <Frame8 />
    </div>
  );
}

function Frame12() {
  return (
    <div className="content-stretch flex flex-col items-center relative shrink-0 w-full">
      <a className="bg-[#4fd1e5] content-stretch cursor-pointer flex items-center justify-center px-[24px] py-[12px] relative rounded-[4px] shrink-0" href="https://m.maatouk@majlisync.com" target="_blank" data-name="EXPLORE SHURAA">
        <p className="[word-break:break-word] font-['Inter:Semi_Bold',sans-serif] font-semibold leading-[20px] not-italic relative shrink-0 text-[#0a0f16] text-[14px] text-left tracking-[1.4px] uppercase whitespace-nowrap">CONTACT EXECUTIVE OFFICE →</p>
      </a>
    </div>
  );
}

function Frame11() {
  return (
    <div className="content-stretch flex flex-[1_0_0] flex-col items-center min-h-px relative w-full">
      <Frame9 />
      <Frame12 />
    </div>
  );
}

function Frame13() {
  return (
    <div className="content-stretch flex flex-col gap-[30px] h-[670px] items-center relative shrink-0 w-full">
      <Frame />
      <Frame11 />
    </div>
  );
}

function Frame1() {
  return (
    <div className="content-center flex flex-wrap gap-y-[10px] items-center relative shrink-0">
      <div className="[word-break:break-word] flex flex-col font-['JetBrains_Mono:Regular',sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[#eaeaea] text-[12px] whitespace-nowrap">
        <p>
          <span className="leading-[normal]">{`Encrypted Connection: `}</span>
          <span className="leading-[normal] text-[#36bfd4]">TLS 1.3</span>
        </p>
      </div>
    </div>
  );
}

function Frame2() {
  return (
    <div className="content-center flex flex-wrap gap-y-[10px] items-center relative shrink-0">
      <div className="[word-break:break-word] flex flex-col font-['JetBrains_Mono:Regular',sans-serif] font-normal justify-center leading-[0] relative shrink-0 text-[#eaeaea] text-[12px] whitespace-nowrap">
        <p>
          <span className="leading-[normal]">{`Sovereign Node: `}</span>
          <span className="leading-[normal] text-[#22c55e]">Active</span>
        </p>
      </div>
    </div>
  );
}

function Frame4() {
  return (
    <div className="content-center flex flex-wrap gap-[10px] h-[16px] items-center justify-center relative shrink-0 w-full">
      <Frame1 />
      <div className="flex h-[16px] items-center justify-center relative shrink-0 w-0">
        <div className="flex-none rotate-90">
          <div className="h-0 relative w-[16px]">
            <div className="absolute inset-[-1px_0_0_0]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 1">
                <line id="Line 15" stroke="var(--stroke-0, white)" strokeOpacity="0.5" x2="16" y1="0.5" y2="0.5" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <Frame2 />
      <div className="flex h-[16px] items-center justify-center relative shrink-0 w-0">
        <div className="flex-none rotate-90">
          <div className="h-0 relative w-[16px]">
            <div className="absolute inset-[-1px_0_0_0]">
              <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 16 1">
                <line id="Line 15" stroke="var(--stroke-0, white)" strokeOpacity="0.5" x2="16" y1="0.5" y2="0.5" />
              </svg>
            </div>
          </div>
        </div>
      </div>
      <div className="content-stretch flex items-center justify-center relative shrink-0" data-name="latency">
        <p className="[word-break:break-word] font-['JetBrains_Mono:Regular',sans-serif] font-normal leading-[0] relative shrink-0 text-[12px] text-white whitespace-nowrap">
          <span className="leading-[normal]">{`Latency: `}</span>
          <span className="leading-[normal] text-[#f59e0b]">32ms</span>
        </p>
      </div>
    </div>
  );
}

function Frame14() {
  return (
    <div className="content-stretch flex flex-col h-[1024px] items-center justify-between py-[10px] relative shrink-0 w-[744px]">
      <div className="content-center flex flex-wrap gap-y-[10px] items-center justify-center relative shrink-0 w-[374px]" data-name="status bar">
        <Frame7 />
      </div>
      <Frame13 />
      <Frame4 />
    </div>
  );
}

function Frame15() {
  return (
    <div className="absolute content-stretch flex h-[1024px] items-center justify-center left-0 top-0 w-[1440px]">
      <Frame14 />
    </div>
  );
}

export default function Dekstop() {
  return (
    <div className="bg-[#0a0f16] relative size-full" data-name="dekstop">
      <Group />
      <Frame15 />
    </div>
  );
}