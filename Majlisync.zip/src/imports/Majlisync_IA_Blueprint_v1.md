# MAJLISYNC / SHURAA
## Complete Information Architecture Blueprint
### Sovereign Decision Intelligence Platform — Internal Technical Reference
**Document Version: v1.0 | Classification: Internal Engineering**

---

# PART 1: PLATFORM CORE PHILOSOPHY

## 1.1 What This Platform Actually Is

Majlisync is not a chatbot. It is not a productivity tool. It is not a wrapper around an LLM.

Majlisync is a **Cognitive Operating System** — a structured deliberation infrastructure that replaces ad-hoc executive decision-making with a rigorously orchestrated, multi-agent intelligence process. Every decision that enters the system is treated as a **mission-critical operation**: it is assigned agents, subjected to adversarial critique, scored for confidence and stability, and ultimately rendered into a tamper-evident, auditable decision document.

The name "Shuraa" (شورى) — derived from Arabic for structured consultative governance — defines the philosophical DNA. The platform operationalizes the principle that no consequential decision should emerge from a single mind. Instead, it routes every strategic question through a structured council of specialized AI agents that argue, challenge, synthesize, and converge — producing a sovereign decision artifact.

## 1.2 Why This System Is Fundamentally Different

| Dimension | Conventional AI Tools | Majlisync / Shuraa |
|---|---|---|
| **Decision Model** | Single LLM response | Multi-agent structured deliberation |
| **Output** | Text answer | Sovereign Decision Document (SDD) |
| **Auditability** | None | SHA-256 hashed audit trail per session |
| **Adversarial Layer** | None | Dedicated Critic Agent (mandatory Red Teaming) |
| **Confidence Scoring** | None | Per-round Consensus + Confidence + Stability metrics |
| **Access Model** | Consumer / API | Role-based: Individual / Enterprise / Government |
| **Deployment** | Cloud-only | Public / Internal / Confidential / Sovereign / On-Premise |
| **Session Memory** | Stateless | Multi-session continuity (Session Number tracking) |
| **Regulatory Grade** | None | CSRF/HSTS/MFA, on-premise sovereign deployment |

## 1.3 The Cognitive Operating System Concept

A traditional operating system manages computational resources. A Cognitive Operating System manages **decision resources** — specifically:

- **Cognitive Diversity Engine:** Multiple agents with different epistemological priors (Strategic, Financial, Legal, Risk, Policy, Intelligence)
- **Adversarial Kernel:** A Critic Agent that exists solely to find failure modes in emerging consensus
- **Consensus Accumulator:** Real-time scoring of how much agreement exists across agents per round
- **Decision Compiler:** Transforms deliberation output into a structured, signed, exportable decision artifact
- **Audit Hypervisor:** Logs every agent action, every state transition, every input transformation with cryptographic integrity

## 1.4 The Sovereign Intelligence Concept

"Sovereign" in Majlisync's context means: **the organization owns the intelligence process end-to-end.** This includes:

- On-premise deployment capability (no cloud dependency)
- Immutable audit trails that cannot be altered post-session
- Data classification enforcement (Public / Internal / Confidential / Sovereign tiers)
- Role-based access that maps to real organizational authority structures
- Export controls per classification level
- Government-grade MFA requirements

## 1.5 The Deliberative AI Concept

Deliberation is the architectural primitive. Every session is structured as a **deliberation round sequence** — not a single inference call. Each round produces:

1. Agent contributions (parallel epistemic inputs)
2. Cross-agent conflict detection
3. Synthesized intelligence update (Main Intelligence Card)
4. Critic Agent challenge
5. Consensus delta measurement
6. Stability score update
7. Next-round briefing

This is fundamentally different from "chain of thought" or "tool use" prompting. The system is architected to **surface disagreement before it surfaces consensus** — because premature consensus is a decision failure mode.

---

# PART 2: GLOBAL PLATFORM HIERARCHY

## 2.1 Master Ecosystem Map

```
MAJLISYNC PLATFORM
├── 1. PUBLIC SURFACES
│   ├── majlisync.com (Landing / Marketing / Trust)
│   └── shuraa.majlisync.com (Product Gateway)
│
├── 2. USER PORTALS
│   ├── lite.shuraa (Individuals)
│   ├── enterprise.shuraa (Organizations)
│   └── [future] gov.shuraa (Government Classified)
│
├── 3. SESSION ENGINE
│   ├── Session Initializer
│   ├── Deliberation Runtime
│   ├── Consensus Engine
│   ├── Conflict Resolver
│   └── Report Compiler
│
├── 4. AI ORCHESTRATION LAYER
│   ├── Orchestrator (Admin Agent)
│   ├── Strategic Agent
│   ├── Financial Agent
│   ├── Critic Agent
│   ├── Legal Agent [Enterprise+]
│   ├── Risk Agent [Enterprise+]
│   ├── Intelligence Agent [Government]
│   └── Policy Agent [Government]
│
├── 5. REPORT ENGINE
│   ├── Sovereign Decision Document (SDD) Generator
│   ├── PDF Exporter
│   ├── DOCX Brief Generator
│   ├── Audit Log Renderer
│   └── Board Share Module
│
├── 6. AUDIT INFRASTRUCTURE
│   ├── SHA-256 Hash Generator (per-session)
│   ├── Immutable Log Pipeline
│   ├── Agent Contribution Logger
│   └── Audit Trail Viewer
│
├── 7. SECURITY LAYER
│   ├── Auth Service (Email / Google OAuth)
│   ├── MFA Enforcer (Government / Sensitive Actions)
│   ├── CSRF Token Manager
│   ├── HSTS / TLS Enforcer
│   ├── Domain Allowlist (Enterprise: no gmail/yahoo)
│   └── Session Token Lifecycle
│
├── 8. ACCESS CONTROL
│   ├── Role Registry (Individual / Enterprise / Government / Admin)
│   ├── Permission Matrix Engine
│   ├── Data Classification Enforcer
│   └── Export Restriction Controller
│
├── 9. API INFRASTRUCTURE
│   ├── API Console (Enterprise)
│   ├── Secure API Key Generator
│   └── Webhook / Integration Layer (Early Access)
│
└── 10. SOVEREIGN DEPLOYMENT MODULE
    ├── On-Premise Configuration
    ├── Air-Gap Mode
    └── Sovereign Upgrade Pathway
```

## 2.2 Platform Hierarchy Tree (Deep Decomposition)

```
MAJLISYNC
│
├── majlisync.com
│   ├── /                          ← Landing Page (Public)
│   ├── /shuraa                    ← Product Overview Redirect
│   ├── /privacy                   ← Privacy Policy
│   └── /terms                     ← Terms of Service
│
├── shuraa.majlisync.com
│   ├── /                          ← Shuraa Product Page
│   ├── /session                   ← Session Entry (post-CTA)
│   └── /reports/public            ← Public Report Gallery
│
├── lite.shuraa.majlisync.com       [ALIAS: individuals.shuraa...]
│   ├── /                          ← Individual Dashboard (Idle State)
│   ├── /session/:id               ← Active Session Screen
│   ├── /session/:id/report        ← Final Report Screen
│   ├── /sessions                  ← Session Archive
│   └── /settings                  ← Language / Account Settings
│
├── enterprise.shuraa.majlisync.com
│   ├── /                          ← Enterprise Dashboard
│   ├── /session/new               ← Session Launcher
│   ├── /session/:id               ← Live Enterprise Session Screen
│   ├── /session/:id/report        ← Enterprise Final Report
│   ├── /archive                   ← Smart Session Archive
│   ├── /api                       ← API Console
│   ├── /templates                 ← Custom Template Request
│   └── /settings                  ← Org Settings / Security
│
└── [future] gov.shuraa.majlisync.com
    ├── /                          ← Government Command Center
    ├── /session/:id               ← Classified Session Screen
    ├── /session/:id/report        ← Classified Decision Report
    ├── /policy-sim                ← Policy Simulation Module
    ├── /intelligence              ← Intelligence Fusion View
    └── /sovereign                 ← Sovereign Deployment Controls
```

---

# PART 3: USER ROLE ARCHITECTURE

## 3.1 Role Registry

### ROLE 1: Individual User
**Context:** Professionals, researchers, analysts using Shuraa for personal strategic decisions.

| Attribute | Value |
|---|---|
| **Portal** | lite.shuraa |
| **Session Limit** | 3 sessions (standard) |
| **Agents Available** | Orchestrator + 2 Specialists (Strategic, Financial or Risk) + Critic |
| **Rounds** | 3 (standard deliberation) |
| **Classification** | Public only |
| **Export** | PDF, DOCX |
| **Audit Trail** | Viewable (SHA-256 modal) |
| **MFA** | Not required (standard auth) |
| **API Access** | None |
| **Custom Templates** | None |
| **Enterprise Banner** | Persistent bottom upsell |

**Restricted Modules:** Legal Agent, Intelligence Agent, Policy Agent, Classified classification tier, API Console, Custom Template Builder, Sovereign Deployment, Session Archive with filters.

---

### ROLE 2: Enterprise Executive
**Context:** C-suite, VPs, Directors operating within an organization's Majlisync enterprise subscription.

| Attribute | Value |
|---|---|
| **Portal** | enterprise.shuraa |
| **Session Limit** | 5 sessions per instance (Strategic: 5 rounds) |
| **Agents Available** | Full council (Strategic, Financial, Legal, Risk, Critic) |
| **Classification** | Public / Internal / Confidential |
| **Export** | PDF, DOCX, Board Share, Clipboard |
| **Audit Trail** | Full (SHA-256 + agent contribution log) |
| **MFA** | Required for sensitive actions (API key generation, Confidential sessions) |
| **API Access** | Read (generate key, view docs) |
| **Session Archive** | Full archive with filter (All / Tactical / Strategic) |
| **Custom Templates** | Request access |
| **Domain Restriction** | Business email mandatory |

**Restricted Modules:** Intelligence Agent, Policy Agent (Government-only), Sovereign Deployment, Air-Gap Mode.

---

### ROLE 3: Government Analyst
**Context:** Policy advisors, defense analysts, intelligence officers operating in government-grade Majlisync instances.

| Attribute | Value |
|---|---|
| **Portal** | gov.shuraa [future] |
| **Session Limit** | Unlimited (by subscription tier) |
| **Agents Available** | Full extended council + Intelligence + Policy Agent |
| **Classification** | All tiers including Sovereign |
| **Export** | Restricted by classification (Sovereign = no external export) |
| **MFA** | Mandatory, hardware key preferred |
| **Deployment** | On-premise / Air-gap eligible |
| **Audit Trail** | Immutable, jurisdiction-controlled |

---

### ROLE 4: Security Auditor
**Context:** Internal or external compliance officers reviewing session integrity.

**Accessible:** Audit Trail Viewer (full), SHA-256 verification tool, Agent Contribution Log, Session Metadata.
**Restricted:** Session content (depends on clearance), Export functionality.
**Interface Difference:** Audit-focused view with timestamp precision, hash verification UI, export restriction indicators.

---

### ROLE 5: AI Operator / System Administrator
**Context:** Internal Majlisync engineering team managing AI agent configurations.

**Accessible:** Agent behavior configs, session routing rules, orchestration pipeline logs, system health telemetry.
**Interface:** Internal admin panel (not exposed to customer-facing surfaces).

---

### ROLE 6: Compliance Officer
**Context:** Ensures sessions, exports, and audit trails meet regulatory requirements.

**Accessible:** Classification labels on all sessions, export audit logs, MFA enforcement reports, data residency configuration.
**Restricted:** Session deliberation content (unless cleared), API keys, agent configuration.

---

## 3.2 Permission Matrix

| Feature | Individual | Enterprise | Government | Auditor | Admin |
|---|---|---|---|---|---|
| Session Initiation | ✅ | ✅ | ✅ | ❌ | ✅ |
| Strategic Agent | ✅ | ✅ | ✅ | ❌ | ✅ |
| Legal Agent | ❌ | ✅ | ✅ | ❌ | ✅ |
| Intelligence Agent | ❌ | ❌ | ✅ | ❌ | ✅ |
| Policy Agent | ❌ | ❌ | ✅ | ❌ | ✅ |
| Confidential Classification | ❌ | ✅ | ✅ | VIEW | ✅ |
| Sovereign Classification | ❌ | ❌ | ✅ | VIEW | ✅ |
| Audit Trail View | ✅ | ✅ | ✅ | ✅ | ✅ |
| API Key Generation | ❌ | ✅ (MFA) | ✅ (MFA) | ❌ | ✅ |
| On-Premise Deploy | ❌ | REQUEST | ✅ | ❌ | ✅ |
| Export as PDF | ✅ | ✅ | RESTRICTED | ❌ | ✅ |
| Export Sovereign | ❌ | ❌ | ❌ | ❌ | ✅ |
| Custom Templates | ❌ | REQUEST | ✅ | ❌ | ✅ |
| Session Archive | Basic | Full | Full + Classified | View-only | Full |

---

# PART 4: INFORMATION ARCHITECTURE — SCREEN BY SCREEN

## 4.1 majlisync.com — Landing Page

**Purpose:** Establish trust, explain value proposition, convert new visitors to session trial. Logged-in users are auto-redirected — this page is effectively for new/unauthenticated visitors only.

**User Mindset:** "What is this? Is it legitimate? Can it help me? Is it secure?"

### Navigation Structure
```
TOP BAR (2px, dynamic color)
  └── 🟢 System Status: Operational [API-driven, color changes on incident]

HEADER
  ├── Logo: Majlisync → links to majlisync.com
  ├── Language Selector: [EN | AR | ID | ZH] (auto-detect on first visit)
  └── CTA: [ Masuk / Login ]

PRIMARY NAVIGATION
  └── None (single-page scroll structure; no nav links to distract from conversion)

FOOTER
  ├── Privacy Policy → /privacy
  ├── Terms of Service → /terms
  └── Version: v0.9 Beta
```

### Page Sections & Component Logic

**SECTION 1: HERO**
- H1: "Sistem Operasi Kognitif untuk Masa Depan"
- System Identity Line (smaller, muted): "Multi-Agent Decision Intelligence Platform"
- Subtitle: Pioneering since 2025. Patent-protected. Empowering individuals, enterprises, governments.
- Button Primary: [ Jelajahi Ekosistem Shuraa ] → /shuraa
- Button Secondary: [ Coba Sesi Sekarang ] → Triggers Try Session Modal

**Try Session Modal Flow:**
```
Click CTA
  └── Modal appears (center overlay)
        └── Input: Email address
              └── Submit
                    └── Auto-redirect → lite.shuraa
                          └── AI session starts immediately
```

**SECTION 2: CORE CAPABILITIES (3-Card Grid)**

Card 1 — Shuraa Engine
  - Status badge: [ Aktif ]
  - CTA: [ Coba Sekarang ] → same modal flow

Card 2 — API Integration
  - Status badge: [ Akses Awal / Early Access ]
  - CTA: [ Daftar Akses ] → Form modal (collect name, email, org)
  - **API STATUS BEHAVIOR:** On submit → DO NOT close modal → Show "Permintaan Diterima" for 3 seconds → Auto-close

Card 3 — Secure Deployment
  - Body text: "Supports: Public, Internal, Confidential, Sovereign"
  - No CTA (informational)

**SECTION 3: USE CASES (Static Cards)**
- Strategic Decisions | Policy Evaluation | Investment Governance
- Static display, no interactive behavior

**SECTION 4: DECISION GALLERY (Interactive Chips)**
- Chips: Budget Allocation | Risk Reduction | Policy Simulation | Legal Review
- Behavior: Click chip → Open Try Session modal with chip text pre-filled as input

**SECTION 5: SYSTEM TRUST LINE**
- Horizontal typographic bar: Secure Architecture | Immutable Audit Trails | On-Premise Ready

---

## 4.2 shuraa.majlisync.com — Product Gateway Page

**Purpose:** Convert intent into trial. This page exists for users who want to understand Shuraa before committing. Conversion is the primary objective of every element.

**User Mindset:** "Show me what this does and let me try it immediately."

### Navigation Structure
```
TOP BAR: 🟢 System Status (API-dynamic)

HEADER
  ├── Breadcrumb: Majlisync / Shuraa
  ├── Language Selector
  └── [ Masuk / Login ]

CONTEXTUAL NAV (within page)
  └── Scroll-based sections (no secondary nav tabs)
```

### Page Sections

**SECTION 1: HERO + QUICK TRIAL**
- H1: "Dewan Agen AI untuk Keputusan Krusial Anda"
- **Quick Input Box:** Large textarea with animated placeholder cycling through example decisions
  - Placeholder examples (typing animation, cycling):
    - "Apakah kami harus mengakuisisi perusahaan ini?"
    - "Bagaimana kami mengelola risiko investasi Q3?"
    - "Evaluasi kebijakan anggaran infrastruktur nasional..."
- CTA Button: [ Bentuk Dewan & Mulai Analisis ]
- Micro-text below button: "Tanpa kartu kredit. Mulai dalam hitungan detik."

**MANDATORY FLOW:**
```
User types in Quick Input Box
  └── Click CTA
        └── Email Input Modal appears
              └── Submit email
                    └── Auto-redirect → lite.shuraa
                          └── Pre-filled with user's typed text
```

**PORTAL SELECTOR (below CTA):**
```
[ Individu ]   [ Perusahaan ]   [ Pemerintah ↗ MFA Required (tooltip) ]
```

**SECTION 2: DECISION GALLERY (Chips)**
- Interactive chips: Budget Allocation | Risk Reduction | Legal Review | Policy Simulation
- Behavior: Click → fills Quick Input Box (does NOT open modal directly)

**SECTION 3: COGNITOŚ ARCHITECTURE**
- Title: "Powered by CognitoS Decision Engine: From Question to Sovereign Decision"
- **Visual: Consensus Orbit Diagram (CSS/SVG Animation)**
  - 4 light nodes (agents) orbiting a central user problem node
  - Data exchange lines visible between agents
  - Convergence animation into a decision document below
  - Represents: Hybrid Research → Cognitive Diversity → Red Teaming → Consensus
- Value bullets: 3 Sessions (Individual) / 5 Sessions (Enterprise), Independent Critic Agent, Full Audit Trail

**SECTION 4: WHY LEADERS USE SHURAA**
- Structured Deliberation | Multi-Agent Consensus | Documented Decisions
- Static, icon + copy cards

**SECTION 5: LIVE SESSION PREVIEW**
- CSS-animated fake conversation between AI agents
- No video (performance constraint)
- Shows agent name badges, message bubbles, consensus meter animating

**SECTION 6: CUSTOM COUNCILS**
- 3 high-value cards: 🏥 Hospitals | ⚖️ Law Firms | 🏦 Banks

**SECTION 7: PUBLIC REPORTS GALLERY**
- Real session report thumbnails (no blur/redaction)
- [ Public ] green badge on each
- [ View Audit Trail ] link below each → opens SHA-256 modal

**SECTION 8: ENTERPRISE BANNER**
- "Representing an organization? Get secure infrastructure."
- CTA: [ Request Enterprise Access ]

**SECTION 9: LITE APP BANNER**
- Mobile app promo with smartphone mockup

---

## 4.3 lite.shuraa — Individual Session Interface

**Purpose:** The primary workspace for individual users. Dual-state: idle (input) and active (deliberation).

**User Mindset (Idle):** "I have a decision. Let me articulate it clearly."
**User Mindset (Active):** "The council is working. I need to observe, trust the process, wait for the output."

### Navigation Structure
```
HEADER
  ├── Logo Majlisync → majlisync.com
  └── Settings (top-right) → Language Dropdown

SIDEBAR (Left)
  ├── [ + New Session ]
  └── [ 📁 Previous Sessions ]
      ├── Session 1 (title preview, date)
      ├── Session 2
      └── ...

FIXED BOTTOM BANNER
  └── Enterprise upsell: "For business/government: Get specialized agents."
        └── [ Request Enterprise Access ]
```

### STATE A: IDLE (Pre-Session)

**The Persistent Glass Card (Center Screen)**
- Large textarea: placeholder = "Keputusan apa yang ingin Anda analisis hari ini?"
- Character counter: 0 / 2000
- Button: [ Bentuk Dewan - Assemble Council ] — **DISABLED if input empty**

**INFORMATION PRIORITY:**
1. Empty state communicates readiness
2. Character counter sets expectation
3. Disabled button prevents premature action
4. Sidebar provides session history context

---

### STATE B: TRANSITION (Animation Sequence — NO PAGE RELOAD)

**Step 1 — Card Shift:** Glass card performs translateY to active session anchor position. Size unchanged.

**Step 2 — Content Crossfade:**
- "Assemble Council" button fades out
- Textarea fades out
- Text display container crossfades in (within same card)

**Step 3 — Admin Agent Materialization:**
- Glass Sphere of Orchestrator agent scales from 0 → 1 from background cosmos
- Arrives at position above/adjacent to card

**Step 4 — First Typed Message:**
- Orchestrator begins typing: "Memproses file dan memanggil agen..."
- Typing animation, character by character

---

### STATE C: ACTIVE SESSION (Deliberation Mode)

See Section 6.1 for full Live Session Architecture.

---

### STATE D: SESSION REPORT

See Section 6.2 for Final Report Screen specification.

---

## 4.4 enterprise.shuraa — Enterprise Dashboard

**Purpose:** Command-center operations hub. Session launching, archive management, resource access, organizational context.

**User Mindset:** "I'm running this organization's decision intelligence. I need operational awareness and fast access."

**Design Principles:** ZERO Glassmorphism. Flat, professional, command-center aesthetic. Matte Navy (#0B1623). Solid Dark Blue (#152336) surfaces.

### Navigation Structure
```
HEADER
  ├── Logo: Majlisync
  ├── Breadcrumb: Enterprise Dashboard
  └── User Profile / Account

CONTEXT IDENTITY BAR (below header)
  └── "Organization: [Name] | Access: Enterprise | Secure Mode: Active | 🟢 All Systems Operational"

LEFT SIDEBAR (optional or collapsible)
  ├── Dashboard (Home)
  ├── New Session
  ├── Session Archive
  ├── API Console
  ├── Templates
  └── Settings / Security
```

### Dashboard Components

**COMPONENT 1: EXECUTIVE SUMMARY ROW**
```
[ Documented Decisions: 47 ]  [ Active Sessions: 2 ]  [ Available Agents: 5 ]  [ Risk Alerts: 1 ]
```
Each is a KPI card with number, label, and trend indicator.

**COMPONENT 2: SESSION LAUNCHER**
- Mode selector: [ Tactical Session (3 Rounds) ] | [ Strategic Session (5 Rounds) ]
- Textarea: large decision input
- [ Start Council Session ] button
- Micro-text: "Session ID will be generated upon start"

**COMPONENT 3: SMART SESSION ARCHIVE**
- Filter bar: [ All ] [ Tactical ] [ Strategic ]
- Table columns: Session Name | Type | Date | Classification (Internal/Confidential badge) | Status | Actions
- Status colors: Green (Completed) | Amber (Under Review) | Gray (Archived)
- Actions: PDF export icon | Audit Trail icon (→ SHA-256 modal)

**SIDEBAR PANELS (Right or collapsible)**

Panel 1 — Request Custom Template
- Form: sector, use case, specific prompt requirements

Panel 2 — Sector Early Access (Gold accent)
- Program for: Hospitals, Law Firms, Banks

Panel 3 — API Integration
- [ Generate Secure API Key ] button — MFA tooltip required

Panel 4 — Sovereign Upgrade
- [ Request On-Premise Deployment ] form

---

# PART 5: COMPLETE FEATURE TREE

```
MAJLISYNC PLATFORM FEATURES
│
├── 1. AUTH & ACCESS
│   ├── Email-based login (primary)
│   ├── Google OAuth (secondary)
│   ├── Auto-detect browser language (first visit)
│   ├── Auto-redirect logged users (last workspace)
│   ├── MFA enforcement (gov + sensitive actions)
│   ├── Business email domain validation (enterprise)
│   ├── CSRF token injection (all forms)
│   └── HSTS + TLS 1.2+ enforcement
│
├── 2. SESSION ENGINE
│   ├── 2.1 Session Initialization
│   │   ├── Objective intake (textarea → structured input)
│   │   ├── Data classification detection (auto + manual override)
│   │   ├── Deliberation mode selection (Tactical 3R / Strategic 5R)
│   │   ├── Agent roster assignment (by mode + role tier)
│   │   ├── Session ID generation (UUID)
│   │   └── Pre-fill from external entry point (Decision Gallery / Shuraa CTA)
│   │
│   ├── 2.2 Active Deliberation
│   │   ├── Progressive activation flow (Objective Lock → Orchestrator → Theater Assembly)
│   │   ├── Round management (1 of 3 / 1 of 5)
│   │   ├── Agent speaking queue (orchestrator-controlled)
│   │   ├── Real-time insight generation (Main Intelligence Card)
│   │   ├── Laser line visual (active agent → main card)
│   │   ├── Consensus loop (per-round scoring)
│   │   ├── Contradiction analysis
│   │   ├── Conflict detection (inter-agent disagreement)
│   │   ├── Confidence scoring (cumulative)
│   │   ├── Decision stability scoring
│   │   ├── Key risk level update
│   │   └── Next Action Forecast (predictive indicator)
│   │
│   ├── 2.3 Critic Injection System
│   │   ├── Critic Agent mandatory per round
│   │   ├── Adversarial challenge generation
│   │   ├── Assumption falsification attempt
│   │   └── Minority dissent logging
│   │
│   ├── 2.4 Session Closure
│   │   ├── All animations halt
│   │   ├── All agents → Completed ✔
│   │   ├── Background blur overlay (4-6px, 40% opacity)
│   │   ├── Closure modal: "Council Deliberation Completed"
│   │   ├── Final metrics display (Recommendation, Consensus, Confidence, Risk)
│   │   └── CTA: [ View Final Decision Report → ]
│   │
│   └── 2.5 Multi-Session Continuity
│       ├── Session Number tracking (Session: 3 of N)
│       ├── Cross-session topic threading
│       └── Previous sessions sidebar (Individual + Enterprise)
│
├── 3. AI AGENT SYSTEM
│   ├── Orchestrator (Admin Agent) — Cyan
│   │   ├── Session initialization dialogue
│   │   ├── Clarification questioning
│   │   ├── Input locking (Deliberation Lock)
│   │   ├── Agent speaking queue management
│   │   ├── Synthesis coordination
│   │   └── Closure declaration
│   │
│   ├── Strategic Agent — Emerald
│   │   ├── Long-horizon scenario modeling
│   │   ├── Competitive landscape analysis
│   │   ├── Stakeholder impact assessment
│   │   └── Strategic assumption articulation
│   │
│   ├── Financial Agent — Purple
│   │   ├── Quantitative modeling inputs
│   │   ├── Risk-return framing
│   │   ├── Budget / capital allocation analysis
│   │   └── Financial assumption challenge
│   │
│   ├── Critic Agent — Red
│   │   ├── Adversarial challenge per round
│   │   ├── Assumption falsification
│   │   ├── Minority dissent articulation
│   │   └── Stability metric impact
│   │
│   ├── Legal Agent [Enterprise+]
│   │   ├── Regulatory compliance review
│   │   ├── Contract and liability framing
│   │   └── Jurisdiction-specific flagging
│   │
│   ├── Risk Agent [Enterprise+]
│   │   ├── Risk taxonomy mapping
│   │   ├── Probability-impact matrix
│   │   └── Mitigation recommendation
│   │
│   ├── Intelligence Agent [Government]
│   │   ├── Environmental intelligence synthesis
│   │   ├── Threat actor framing
│   │   └── Geopolitical context
│   │
│   └── Policy Agent [Government]
│       ├── Policy precedent analysis
│       ├── Regulatory impact simulation
│       └── Public interest framing
│
├── 4. CONSENSUS ENGINE
│   ├── Per-round consensus delta calculation
│   ├── Consensus Meter (visual, real-time)
│   ├── Confidence Score (cumulative, per agent contribution)
│   ├── Decision Stability Index
│   ├── Contradiction surface (visible to user)
│   ├── Convergence threshold detection
│   └── Consensus Orbit visualization (Shuraa page)
│
├── 5. REPORT ENGINE
│   ├── 5.1 Session Closure Transition
│   │   ├── Overlay morph animation (modal → full screen)
│   │   └── No direct redirect
│   │
│   ├── 5.2 Final Report Document Viewer
│   │   ├── Tab: Executive Summary
│   │   ├── Tab: Full Report
│   │   ├── Tab: Minority Dissents
│   │   └── Tab: Actionable Steps
│   │
│   ├── 5.3 Executive Gauges (Top 20%)
│   │   ├── Recommendation
│   │   ├── Consensus Score
│   │   ├── Confidence Score
│   │   ├── Overall Risk Level
│   │   └── Decision Status (e.g. CONDITIONAL APPROVAL)
│   │
│   ├── 5.4 Decision Timeline
│   │   └── Round 1 → [Agent action] → Round 2 → [Agent action] → Final
│   │
│   └── 5.5 Export & Auth Column (Right 25%)
│       ├── Confidence Trend Sparkline (round 1 → final)
│       ├── Copy to Clipboard
│       ├── Export as PDF
│       ├── Download Brief (.DOCX)
│       ├── Share to Board
│       ├── Agent Authentication List (✔ per agent)
│       └── Document Hash (SHA-256 static)
│
├── 6. AUDIT INFRASTRUCTURE
│   ├── SHA-256 hash generation (per session)
│   ├── Agent contribution log (timestamped)
│   ├── Session state transition log
│   ├── Input immutability seal (post-lock)
│   ├── Audit Trail Viewer modal (triggered from reports + public gallery)
│   └── Export audit log (Enterprise)
│
├── 7. DECISION GALLERY
│   ├── Chip set: Budget Allocation | Risk Reduction | Policy Simulation | Legal Review
│   ├── Behavior on shuraa.majlisync.com: fills Quick Input Box
│   ├── Behavior on majlisync.com: opens Try Session modal with pre-fill
│   └── Mobile: horizontal scroll
│
├── 8. API INFRASTRUCTURE [Enterprise]
│   ├── API Console screen
│   ├── Secure API Key Generator (MFA-gated)
│   ├── Webhook configuration
│   ├── Early Access registration flow
│   └── CORS / CSRF enforcement on all API endpoints
│
└── 9. SOVEREIGN DEPLOYMENT
    ├── On-Premise request form
    ├── Air-Gap mode configuration [Government]
    ├── Data residency declaration
    └── Sovereign Upgrade pathway (sidebar panel)
```

---

# PART 6: SCREEN-BY-SCREEN BREAKDOWN (DEEP)

## 6.1 Live Deliberation Screen — Enterprise Session

**Objective:** Real-time observability of multi-agent deliberation. User watches intelligence being synthesized. Maximum information density with operational clarity.

**User Mindset:** "I need to monitor the council's progress. I need to know: what do they agree on? What's being challenged? How confident are we? When will this conclude?"

### Screen Topology: 30 / 40 / 30

```
┌─────────────────────────────────────────────────────────────────────────┐
│ HEADER: Session ID | Session #3 | Phase: Deliberation | Round: 2 of 5  │
├──────────────────┬──────────────────────────┬───────────────────────────┤
│   LEFT WING      │      CENTER ARENA         │   RIGHT INTELLIGENCE      │
│     (30%)        │         (40%)             │       COLUMN (30%)        │
│                  │                           │                           │
│  ┌────────────┐  │  ─ Strategic Objective ▼  │  Consensus Meter ████░░   │
│  │ Strategic  │  │                           │  Confidence: 74%          │
│  │  Agent     │  │  ┌─ Orchestrator Card ─┐  │  Decision Stability: MED  │
│  │ [SPEAKING] │══│══▶│  Admin Agent (Cyan) │  │  Key Risk Level: HIGH     │
│  └────────────┘  │  └─────────────────────┘  │                           │
│                  │                           │  Next Action Forecast:    │
│  ┌────────────┐  │  ┌── MAIN INTEL CARD ──┐  │  "Critic reviewing        │
│  │ Financial  │  │  │  Real-time bullets  │  │   financial assumptions"  │
│  │  Agent     │══│══▶│  • Finding 1       │  │                           │
│  └────────────┘  │  │  • Finding 2        │  │  Agent Contribution:      │
│                  │  │  • Finding 3        │  │  Strategic  ████████ 82%  │
│  Conflict Lvl:   │  └─────────────────────┘  │  Financial  ██████░░ 67%  │
│  🟠 MODERATE     │                           │  Critic     ████░░░░ 45%  │
│                  │  ┌── CRITIC PANEL ─────┐  │  Orchestr.  ████████ 91%  │
│                  │  │  Critic Agent (Red)  │  │                           │
│                  │  │  "Challenge: The     │  │  System Integrity: ✔      │
│                  │  │  financial model     │  │  Latency: 142 ms          │
│                  │  │  assumes stable..."  │  │                           │
│                  │  └─────────────────────┘  │  ─────────────────────────│
│                  │                           │  🔍 Search logs...   [EXP]│
│                  │                           │                           │
│                  │                           │  [12:04:31] Strategic     │
│                  │                           │  ▼ Initiated scenario...  │
│                  │                           │                           │
│                  │                           │  [12:04:47] Financial     │
│                  │                           │  ▼ Counter-model          │
├──────────────────┴──────────────────────────┴───────────────────────────┤
│ FOOTER: Elapsed: 02:14 | Estimated Completion: 00:45 | Status: Active   │
└─────────────────────────────────────────────────────────────────────────┘
```

### Progressive Activation Flow (Detailed)

**PHASE 1 — Objective Lock**
- User's input text transitions from editable textarea → collapsed Strategic Objective Panel
- Panel shows input text, truncated, with expand chevron ▼
- Inputs are now locked. Alert banner: 🔒 [ Inputs Locked — Deliberation Started ]

**PHASE 2 — Orchestrator Awakens**
- Orchestrator Card (Cyan) materializes in Center Arena
- Orchestrator begins clarifying questions if ambiguity detected
- Status: "Clarification Phase" in header

**PHASE 3 — Lockdown**
- No further user input accepted
- All input fields disabled + greyed
- Input lock alert persists

**PHASE 4 — Theater Assembly (Staggered Fade-In)**
- Left Wing: Strategic Agent appears (fade-in, 0.3s delay)
- Left Wing: Financial Agent appears (fade-in, 0.6s delay)
- Center: Critic Panel appears at bottom of center column (fade-in, 0.9s delay)

**PHASE 5 — Live Stream**
- Main Intelligence Card begins populating with real-time bullet points
- Right Column log begins scrolling
- Laser lines animate from active agent → Main Intel Card during that agent's speaking turn
- Consensus Meter begins updating

### Component Detail: Decision Spine
- Thin vertical line (Muted Gold #C6A75E)
- Runs full screen height
- Centered behind Center Arena cards
- Represents the singular decision axis around which all agent argument orbits

### Component Detail: Agent Cards (Left Wing)
- Solid Dark Blue (#152336) container
- 4px border in agent color (Cyan / Emerald / Purple / Red)
- Agent name in agent color
- Status indicator: SPEAKING (pulsing border) / ANALYZING / COMPLETE ✔
- Conflict Level indicator (Cyan=Low, Amber=Moderate, Red=High)
- Click agent name → tooltip: agent role summary

### Component Detail: Main Intelligence Card
- Largest element on screen
- Updates in real-time via streaming
- Bullet point format: concise intelligence fragments
- Laser lines from agents flow INTO this card (SVG overlay, animated)
- Represents synthesized emerging consensus intelligence

### Component Detail: Collapsed Log (Right Column, Bottom 50%)
- Each log entry: [Timestamp] [AgentName-colored] + 2-line preview
- Click to expand → full message visible
- Search bar: filters log by agent name or keyword
- [ Export Logs ] button

---

## 6.2 Final Report Screen — .../session/report

**Objective:** Deliver the sovereign decision artifact. Executive consumption. Exportable, signed, auditable.

**User Mindset:** "Give me the answer, justify it, and let me share it."

### Layout: Top 20% / Left-Center 75% / Right 25%

**TOP SECTION — Executive Gauges**
```
[ Recommendation: PROCEED WITH CONDITIONS ]
[ Consensus: 87% ]  [ Confidence: 74% ]  [ Overall Risk: MODERATE ]  [ Status: CONDITIONAL APPROVAL ]

Key Decision Drivers:
• Financial model shows positive NPV only if FX assumptions hold
• Strategic alignment confirmed by 4 of 5 agents
• Legal risk identified in Clause 14.3 — requires amendment before execution
```

**CENTER-LEFT SECTION — Document Viewer (75% width)**

Tab System:
- **Executive Summary** — 1-page distillation, Markdown formatted
- **Full Report** — Complete deliberation output, all rounds, all agent voices
- **Minority Dissents** — Critic Agent challenges and dissenting views not resolved in consensus
- **Actionable Steps** — Numbered executable actions with owners (critical for executives)

**Decision Timeline (bottom of document)**
```
Round 1: Strategic framing → Round 2: Financial modeling → Round 3: Critic challenge →
Round 4: Legal review → Round 5: Final consensus formation
```

**RIGHT COLUMN — Actions & Authentication (25% width)**

Confidence Trend Sparkline:
```
Round:  1    2    3    4    5
Score:  45%  58%  61%  71%  74%  ─────▶ (sparkline chart)
```

Export Buttons:
- [ Copy to Clipboard ]
- [ Export as PDF ]
- [ Download Brief (.DOCX) ]
- [ Share to Board ]

Authentication Block:
```
Document Authentication
─────────────────────────────
✔ Strategic Agent
✔ Financial Agent
✔ Legal Agent
✔ Risk Agent
✔ Critic Agent
✔ Orchestrator

SHA-256:
a3f9c2b1d7e4...8f0a2c5b9d3e
```

---

## 6.3 Audit Trail Viewer — Modal

**Trigger:** Clicking audit trail link in reports or public gallery

**Modal Content:**
```
Audit Trail — Session [ID]
─────────────────────────────────────────────────────
Document Hash (SHA-256):
a3f9c2b1d7e4829cf0b53a71d6e8f2c94b1a3d7e0f5c2b9a4

Generated: [ISO timestamp]
Session Status: COMPLETED ✔
Classification: PUBLIC

─ AGENT CONTRIBUTION LOG ─
[12:04:31] Orchestrator — Session initialized. Objective locked.
[12:04:47] Strategic Agent — Scenario model: 3 trajectories presented.
[12:05:12] Financial Agent — NPV model applied. Sensitivity matrix generated.
[12:05:38] Critic Agent — Challenge raised: FX assumption stability.
[12:06:01] Orchestrator — Synthesis round initiated.
[12:06:44] Consensus Engine — Threshold reached: 87%.
[12:07:02] Orchestrator — Deliberation closed. Report compiled.

[ Verify Hash ]  [ Export Audit Log ]  [ Close ]
```

---

# PART 7: LIVE SESSION SYSTEM ARCHITECTURE

## 7.1 Session Lifecycle (End-to-End)

```
PHASE 0: PRE-SESSION
├── User inputs decision objective (textarea)
├── Character validation (max 2000)
├── Empty state guard (button disabled)
└── Submit trigger

PHASE 1: INITIALIZATION (0–5s)
├── Session ID generated (UUID)
├── Data classification auto-detected
├── Deliberation mode resolved (Tactical/Strategic)
├── Agent roster assembled based on mode + user tier
├── Audit pipeline initialized
├── First audit log entry: "Session initialized"
└── Transition animation begins (Card Shift + Content Crossfade)

PHASE 2: ORCHESTRATOR CLARIFICATION (5–30s)
├── Orchestrator Agent materializes
├── Objective displayed to user (read-only)
├── Orchestrator types clarifying questions (if ambiguity)
├── User may respond (within clarification window)
└── Objective locked → Deliberation begins

PHASE 3: DELIBERATION ROUNDS (Per-Round Loop)
│
│  ┌── ROUND N ──────────────────────────────────────────┐
│  │                                                      │
│  │  Step 1: Orchestrator issues round brief to agents   │
│  │  Step 2: Strategic Agent contribution (streamed)     │
│  │  Step 3: Financial Agent contribution (streamed)     │
│  │  Step 4: [Legal/Risk Agent if Enterprise] (streamed) │
│  │  Step 5: Main Intelligence Card update               │
│  │  Step 6: Critic Agent challenge (Red Team injection) │
│  │  Step 7: Consensus Engine scores:                    │
│  │          - Consensus Delta                           │
│  │          - Confidence Score update                   │
│  │          - Decision Stability index                  │
│  │          - Key Risk Level                            │
│  │  Step 8: Next Action Forecast update                 │
│  │  Step 9: Audit log entries for all agent actions     │
│  │  Step 10: Header updates: Round [N] of [MAX]         │
│  └──────────────────────────────────────────────────────┘
│
│  Repeat for all rounds (3 Tactical / 5 Strategic)

PHASE 4: CONSENSUS THRESHOLD OR ROUND EXHAUSTION
├── If consensus ≥ threshold → early convergence flag
├── If rounds exhausted → deliberation close
└── Orchestrator declares: "Deliberation Complete"

PHASE 5: SESSION CLOSURE TRANSITION
├── All laser animations halt
├── All agent panels → COMPLETED ✔
├── Background blur applied (4-6px, opacity 40%)
├── Closure modal appears: "Council Deliberation Completed"
├── 4 final metrics displayed
└── CTA: [ View Final Decision Report → ]

PHASE 6: REPORT MORPH
├── User clicks CTA
├── Modal overlay expands (CSS transform) → full-screen Document Viewer
└── No redirect (same-page morph transition)

PHASE 7: POST-SESSION ARCHIVING
├── Session written to archive (Smart Session Archive)
├── SHA-256 hash computed and stored
├── Audit log finalized (immutable)
└── Session card appears in sidebar (Individuals) or archive table (Enterprise)
```

---

# PART 8: AI AGENT ARCHITECTURE

## 8.1 Agent Registry

### Orchestrator Agent (Administrative)
**Color:** Cyan | **Position:** Center Arena

**Responsibilities:**
- Sole agent that communicates directly with user (clarification phase)
- Controls agent speaking queue within each round
- Synthesizes round output into Main Intelligence Card update brief
- Issues round briefing to all agents before each round
- Detects convergence threshold and declares close
- Signs session completion in audit log

**Speaking Hierarchy:** Always speaks first (round brief) and last (synthesis). Never speaks simultaneously with specialist agents.

**Conflict Behavior:** When inter-agent conflict is detected, Orchestrator surfaces it in Main Intel Card as "Open Contradiction" rather than suppressing it.

**UI Visibility:** Card in Center Arena (always visible). Laser line from Orchestrator card also used during synthesis phases.

---

### Strategic Agent
**Color:** Emerald | **Position:** Left Wing (top)

**Responsibilities:**
- Long-horizon scenario construction (3+ futures)
- Stakeholder map and political economy analysis
- Competitive positioning assessment
- Strategic assumption articulation (fed to Critic)

**Round Behavior:** Speaks in first half of each round. Input is scenario-based (qualitative + structural).

**Conflict System:** If Financial Agent's model contradicts Strategic Agent's trajectory assumptions → Conflict Level raises → flagged in Right Column.

**Weighting:** High influence on Consensus Score in rounds 1-2, lower in final rounds (Critic and synthesis dominate).

---

### Financial Agent
**Color:** Purple | **Position:** Left Wing (bottom)

**Responsibilities:**
- Quantitative modeling (NPV, IRR, payback, sensitivity)
- Budget / capital allocation framing
- FX and macro assumption challenges
- Risk-adjusted return framing

**Round Behavior:** Speaks after Strategic Agent per round. Provides quantitative grounding to qualitative strategic positions.

**Conflict System:** Most frequent conflict source — Financial Agent's quantitative constraints often challenge Strategic Agent's optimistic trajectories.

**Weighting:** High influence on Confidence Score (quantitative backing raises confidence).

---

### Critic Agent
**Color:** Red | **Position:** Center Arena (bottom, below Main Intel Card)

**Responsibilities:**
- Mandatory adversarial challenge injection every round
- Identify and articulate assumptions most likely to fail
- Produce minority dissents (logged to Minority Dissents tab)
- Attempt to falsify emerging consensus before it solidifies

**Speaking Hierarchy:** Always speaks last in each round, after all specialist agents.

**Conflict Behavior:** Critic is the only agent permitted to reduce Consensus Score — its challenge can cause Consensus Meter to drop between rounds.

**UI Visibility:** Fixed position below Main Intel Card. Always visible during deliberation. Cannot be dismissed or minimized.

**Weighting:** Critic contribution weight increases in later rounds — final round Critic challenge has maximum influence on Decision Stability Score.

---

### Legal Agent [Enterprise+]
**Color:** Amber | **Position:** Left Wing (if present) or Right Wing

**Responsibilities:**
- Regulatory compliance scan (jurisdiction-sensitive)
- Contract and liability surface identification
- Clause-level flagging in financial / operational decisions
- Governs "Legal Review" Decision Gallery chip sessions

---

### Risk Agent [Enterprise+]
**Color:** Orange | **Position:** Adjacent to Financial in Left Wing

**Responsibilities:**
- Risk taxonomy mapping (Strategic, Operational, Financial, Regulatory, Reputational)
- Probability × Impact matrix construction
- Mitigation recommendation generation
- Key Risk Level indicator ownership

---

### Intelligence Agent [Government]
**Responsibilities:**
- Environmental intelligence synthesis (geopolitical, threat actor, signals)
- Open-source + classified intelligence framing (tiered by deployment)
- Provides context that other agents cannot access (jurisdiction-specific)

---

### Policy Agent [Government]
**Responsibilities:**
- Policy precedent analysis (prior decisions, legal frameworks)
- Regulatory impact simulation for policy options
- Public interest and political feasibility framing

---

## 8.2 Agent Interaction Rules

```
SPEAKING ORDER (per round):
1. Orchestrator → round brief
2. Strategic Agent → scenario input
3. Financial Agent → quantitative grounding
4. [Legal Agent if present] → compliance framing
5. [Risk Agent if present] → risk taxonomy
6. Critic Agent → adversarial challenge (MANDATORY, always last)
7. Orchestrator → synthesis + Main Intel Card update

SIMULTANEOUS SPEAKING: NEVER. Queue enforced by Orchestrator.

CONFLICT PROTOCOL:
  If Agent A's output contradicts Agent B's:
  → Conflict flag raised in system
  → Conflict Level indicator updates (Right Column)
  → Orchestrator surfaces contradiction in Main Intel Card
  → Critic Agent receives conflict as mandatory challenge input next round

AGENT CLICKABILITY (UI):
  → Click agent name / card → tooltip: role summary + current contribution %
  → Not navigatable to agent-specific screen (all visible in central UI)
```

---

# PART 9: COMMAND CENTER UI LOGIC

## 9.1 Dense UI Philosophy

The enterprise and government interfaces operate on the principle that **information density is a feature, not a flaw**. The target user — an executive, analyst, or commander — has been trained to extract signal from dense interfaces. Consumer-style simplification would be an insult to their cognitive capacity and would reduce operational effectiveness.

**Layering Principles:**

**Layer 1 — Ambient State (always visible, peripheral awareness):**
- Status bar (system health)
- Session phase + round indicator (header)
- Footer telemetry (elapsed time, completion estimate)
- Consensus Meter, Decision Stability (right column)

**Layer 2 — Active Attention (center of screen, requires focus):**
- Main Intelligence Card (streaming insights)
- Orchestrator Card (communication hub)
- Critic Panel (challenge layer)

**Layer 3 — On-Demand Detail (collapsed by default, expand on click):**
- Collapsed Log entries (expand for full message)
- Strategic Objective (collapsed panel, expand ▼)
- Agent role tooltips (click-triggered)

**Layer 4 — Export / Post-Session (available after deliberation):**
- Report viewer
- Audit trail modal
- Export actions

## 9.2 Executive Scanning Behavior

Research on command center operators and executive dashboards shows a consistent **scanning pattern:**

```
1. TOP STRIP → System health (is anything broken?)
2. HEADER → What phase are we in? What round?
3. RIGHT COLUMN → What are the key numbers? (Consensus, Confidence, Risk)
4. CENTER → What is the current synthesized intelligence?
5. LEFT WING → Who is speaking? What is the conflict level?
6. FOOTER → How much time is left?
```

Every design decision in the enterprise session screen is optimized to support this scanning sequence without requiring scrolling.

## 9.3 Mission-Critical Readability Principles

- **Agent color coding** is the fastest information carrier. Color = identity. Consistent across all touchpoints (border, name, laser line, log entry).
- **Decision Spine** (gold vertical line) provides a physical anchor point that the eye returns to after scanning extremities.
- **Collapsed logs** prevent information overload while keeping data accessible.
- **Status badge colors** (Green/Amber/Gray) communicate session state in <100ms.
- **No decorative elements** in enterprise/government interfaces. Every pixel carries operational information.

---

# PART 10: SECURITY ARCHITECTURE

## 10.1 Authentication Flow

```
STANDARD (Individual):
  Email input → Magic link or password → Session token issued → Auto-redirect to last workspace

ENTERPRISE:
  Business email domain validation (reject gmail/yahoo/hotmail/etc.)
  → Standard auth
  → Session token with org-scoped permissions

GOVERNMENT:
  Business/government email
  → MFA enforcement (TOTP minimum, hardware key preferred)
  → Jurisdiction-validated session
  → Enhanced session token with classification scope
```

## 10.2 Data Classification System

| Tier | Description | Export | Deployment | MFA |
|---|---|---|---|---|
| **Public** | Non-sensitive decisions, general strategy | All formats | Cloud | No |
| **Internal** | Organization-internal strategy, not for external sharing | PDF, DOCX (org-watermarked) | Cloud | Recommended |
| **Confidential** | Sensitive commercial, legal, financial decisions | PDF (encrypted), restricted DOCX | Cloud (isolated) | Required |
| **Sovereign** | Government-classified, national security | No external export | On-Premise / Air-Gap | Hardware key |

## 10.3 Audit Trail Architecture

```
SESSION EVENTS → Audit Logger
├── Input received (hash of input text)
├── Classification assigned
├── Agent actions (timestamped, agent ID)
├── Consensus score changes (per round)
├── User actions during session (none allowed post-lock)
├── Export events (what was exported, by whom, when)
└── Session closure (hash of final document)

STORAGE: Append-only log (immutable)
INTEGRITY: SHA-256 hash of full log at session close
DISPLAY: Audit Trail Viewer Modal (SHA-256 + agent log list)
ENTERPRISE EXPORT: [ Export Logs ] → structured JSON
```

## 10.4 Transport & Infrastructure Security

```
TLS: Minimum TLS 1.2 enforced. TLS < 1.2 → connection rejected.
HSTS: Preload across *.majlisync.com
CSRF: Token attached to all sensitive form submissions
CORS: Strict origin policy (no wildcard)
API Keys: MFA-gated generation, scoped by org, revocable
On-Premise: Air-gap mode disables all external API calls
```

---

# PART 11: DATA FLOW & SYSTEM FLOW

## 11.1 End-to-End Operational Flow

```
USER INPUT
    │
    ▼
┌──────────────────────────────────────────────────────────┐
│ INPUT LAYER                                               │
│  • Textarea intake                                        │
│  • Character validation                                   │
│  • Language detection                                     │
│  • Classification pre-detection (keyword heuristics)     │
└──────────────────────────┬───────────────────────────────┘
                           │
                           ▼
┌──────────────────────────────────────────────────────────┐
│ SESSION INITIALIZATION LAYER                              │
│  • Session ID generation                                  │
│  • User role validation                                   │
│  • Agent roster assembly                                  │
│  • Deliberation mode assignment                           │
│  • Audit pipeline open                                    │
└──────────────────────────┬───────────────────────────────┘
                           │
                           ▼
┌──────────────────────────────────────────────────────────┐
│ ORCHESTRATION LAYER                                       │
│  • Orchestrator receives objective                        │
│  • Clarification cycle (if needed)                        │
│  • Round brief generation (per round)                     │
│  • Agent speaking queue management                        │
│  • Synthesis compilation (per round)                      │
└──────────────────────────┬───────────────────────────────┘
                           │
              ┌────────────┼────────────┐
              │            │            │
              ▼            ▼            ▼
    STRATEGIC AGENT   FINANCIAL AGENT  [LEGAL/RISK]
    contribution       contribution     contribution
              │            │            │
              └────────────┴────────────┘
                           │
                           ▼
┌──────────────────────────────────────────────────────────┐
│ CRITIC INJECTION LAYER                                    │
│  • Receives all agent contributions                       │
│  • Generates adversarial challenge                        │
│  • Flags assumptions for falsification                    │
│  • Minority dissent logging                               │
└──────────────────────────┬───────────────────────────────┘
                           │
                           ▼
┌──────────────────────────────────────────────────────────┐
│ CONSENSUS ENGINE                                          │
│  • Cross-agent agreement scoring                          │
│  • Conflict detection and flagging                        │
│  • Consensus delta calculation                            │
│  • Confidence score update                                │
│  • Decision stability index                               │
│  • Key risk level update                                  │
└──────────────────────────┬───────────────────────────────┘
                           │
                     [REPEAT N ROUNDS]
                           │
                           ▼
┌──────────────────────────────────────────────────────────┐
│ REPORT COMPILATION LAYER                                  │
│  • Executive Summary generation                           │
│  • Full Report assembly (all rounds)                      │
│  • Minority Dissents compilation                          │
│  • Actionable Steps extraction                            │
│  • Decision Timeline construction                         │
│  • Confidence Trend Sparkline data                        │
│  • Key Decision Drivers (3 bullets)                       │
└──────────────────────────┬───────────────────────────────┘
                           │
                           ▼
┌──────────────────────────────────────────────────────────┐
│ AUDIT & SIGNING LAYER                                     │
│  • Audit log finalized (immutable)                        │
│  • SHA-256 hash computed over: input + all agent actions  │
│    + consensus scores + final report content              │
│  • Document hash written to report                        │
│  • Session archived                                       │
└──────────────────────────┬───────────────────────────────┘
                           │
                           ▼
┌──────────────────────────────────────────────────────────┐
│ DELIVERY LAYER                                            │
│  • Overlay morph → Document Viewer                        │
│  • Export actions enabled                                 │
│  • Audit Trail Viewer available                           │
│  • Session card added to archive                          │
└──────────────────────────────────────────────────────────┘
```

---

# PART 12: FINAL MASTER INFORMATION ARCHITECTURE TREE

```
MAJLISYNC PLATFORM
│
├── PUBLIC SURFACES
│   │
│   ├── majlisync.com
│   │   ├── [COMPONENT] Status Bar (API-dynamic, 2px)
│   │   │   ├── State: Operational [🟢 #00C853]
│   │   │   ├── State: Maintenance [🟠 #FF6D00]
│   │   │   └── State: Incident [🔴 #D50000]
│   │   │
│   │   ├── [COMPONENT] Header
│   │   │   ├── Logo (→ majlisync.com)
│   │   │   ├── Language Selector [EN | AR | ID | ZH]
│   │   │   │   └── State: Auto-detected on first visit
│   │   │   └── Login CTA Button
│   │   │
│   │   ├── [SECTION] Hero
│   │   │   ├── H1 (Headline)
│   │   │   ├── System Identity Line
│   │   │   ├── Subtitle (trust signals)
│   │   │   ├── [BUTTON] Explore Shuraa → /shuraa
│   │   │   └── [BUTTON] Try a Session
│   │   │       └── [MODAL] Try Session
│   │   │           ├── Email Input
│   │   │           ├── Submit → redirect to lite.shuraa
│   │   │           └── State: Pre-filled (from Decision Gallery chip)
│   │   │
│   │   ├── [SECTION] Core Capabilities (3-card grid)
│   │   │   ├── Card: Shuraa Engine
│   │   │   │   ├── Status Badge: Active
│   │   │   │   └── CTA: Try Now → Try Session Modal
│   │   │   ├── Card: API Integration
│   │   │   │   ├── Status Badge: Early Access
│   │   │   │   └── [MODAL] API Access Request Form
│   │   │   │       ├── State: Idle → form
│   │   │   │       ├── State: Submitted → "Request Received" (3s)
│   │   │   │       └── State: Auto-close
│   │   │   └── Card: Secure Deployment
│   │   │       └── Copy: Public / Internal / Confidential / Sovereign
│   │   │
│   │   ├── [SECTION] Use Cases (Static)
│   │   │   ├── Strategic Decisions
│   │   │   ├── Policy Evaluation
│   │   │   └── Investment Governance
│   │   │
│   │   ├── [SECTION] Decision Gallery (Interactive)
│   │   │   ├── Chip: Budget Allocation
│   │   │   ├── Chip: Risk Reduction
│   │   │   ├── Chip: Policy Simulation
│   │   │   └── Chip: Legal Review
│   │   │       └── Behavior: Click → Try Session Modal (pre-filled)
│   │   │
│   │   ├── [SECTION] System Trust Line
│   │   │   ├── Secure Architecture
│   │   │   ├── Immutable Audit Trails
│   │   │   └── On-Premise Ready
│   │   │
│   │   └── [COMPONENT] Footer
│   │       ├── Privacy Policy → /privacy
│   │       ├── Terms of Service → /terms
│   │       └── Version: v0.9 Beta
│   │
│   └── shuraa.majlisync.com
│       ├── [COMPONENT] Status Bar (same as landing)
│       ├── [COMPONENT] Header (Breadcrumb: Majlisync / Shuraa)
│       │
│       ├── [SECTION] Hero + Quick Trial
│       │   ├── H1
│       │   ├── Quick Input Box (animated placeholder)
│       │   ├── [BUTTON] Assemble Council & Start Analysis
│       │   │   └── Flow: Type → Click → Email Modal → Redirect lite.shuraa
│       │   ├── Micro-text: No credit card / Start in seconds
│       │   └── Portal Selector
│       │       ├── Individuals → lite.shuraa
│       │       ├── Enterprises → enterprise.shuraa
│       │       └── Governments → [future] + MFA tooltip
│       │
│       ├── [SECTION] Decision Gallery
│       │   ├── Chip: Budget Allocation
│       │   ├── Chip: Risk Reduction
│       │   ├── Chip: Legal Review
│       │   └── Chip: Policy Simulation
│       │       └── Behavior: fills Quick Input Box (no modal)
│       │
│       ├── [SECTION] CognitoS Architecture
│       │   ├── Title
│       │   ├── Consensus Orbit Diagram (CSS/SVG animated)
│       │   │   ├── Agent nodes (4)
│       │   │   ├── Data exchange lines
│       │   │   └── Convergence animation → document
│       │   └── Value Bullets
│       │
│       ├── [SECTION] Why Leaders Use Shuraa
│       ├── [SECTION] Live Session Preview (CSS fake conversation)
│       ├── [SECTION] Custom Councils (3 cards: Hospital / Law / Bank)
│       ├── [SECTION] Public Reports Gallery
│       │   ├── Report Thumbnails (no redaction)
│       │   ├── Badge: [ Public ]
│       │   └── Link: [ View Audit Trail ] → SHA-256 Modal
│       ├── [SECTION] Enterprise Banner
│       └── [SECTION] Lite App Banner
│
├── USER PORTALS
│   │
│   ├── lite.shuraa (Individuals)
│   │   ├── [COMPONENT] Header (Logo → majlisync.com)
│   │   ├── [COMPONENT] Settings → Language dropdown
│   │   ├── [COMPONENT] Sidebar
│   │   │   ├── [ + New Session ]
│   │   │   └── [ 📁 Previous Sessions ] (list)
│   │   ├── [COMPONENT] Fixed Bottom Banner → Enterprise upsell
│   │   │
│   │   ├── [SCREEN STATE] IDLE
│   │   │   └── [COMPONENT] Persistent Glass Card
│   │   │       ├── Textarea: decision input
│   │   │       ├── Character Counter: 0/2000
│   │   │       ├── [BUTTON] Assemble Council
│   │   │       │   ├── State: Disabled (input empty)
│   │   │       │   └── State: Active (input present)
│   │   │       └── Position: centered on screen
│   │   │
│   │   ├── [SCREEN STATE] TRANSITION
│   │   │   ├── Animation: Card translateY to anchor position
│   │   │   ├── Content crossfade: button+textarea → text display container
│   │   │   └── Admin Agent: Scale 0→1, materializes, begins typing
│   │   │
│   │   ├── [SCREEN STATE] ACTIVE SESSION
│   │   │   └── → See Enterprise Session Screen architecture (simplified agent set)
│   │   │
│   │   └── [SCREEN STATE] REPORT
│   │       └── → Final Report Screen
│   │
│   └── enterprise.shuraa
│       ├── [COMPONENT] Header
│       ├── [COMPONENT] Context Identity Bar
│       │   └── Org Name | Access Level | Secure Mode | System Status
│       │
│       ├── [SCREEN] Dashboard
│       │   ├── Executive Summary (4 KPIs)
│       │   ├── Session Launcher
│       │   │   ├── Mode: Tactical (3R)
│       │   │   ├── Mode: Strategic (5R)
│       │   │   ├── Textarea: decision input
│       │   │   └── [BUTTON] Start Council Session
│       │   ├── Smart Session Archive
│       │   │   ├── Filter: All | Tactical | Strategic
│       │   │   ├── Table: Name, Type, Date, Classification, Status, Actions
│       │   │   │   ├── Action: PDF Export
│       │   │   │   └── Action: Audit Trail → SHA-256 Modal
│       │   │   └── Status badges: Green | Amber | Gray
│       │   └── Exclusive Sidebar
│       │       ├── Panel: Custom Template Request
│       │       ├── Panel: Sector Early Access (Gold)
│       │       ├── Panel: API Integration + Key Generator
│       │       └── Panel: Sovereign Upgrade
│       │
│       ├── [SCREEN] Active Enterprise Session
│       │   ├── [COMPONENT] Header Telemetry
│       │   │   └── Session ID | Session # | Phase | Round N of MAX
│       │   ├── [ZONE] Left Wing (30%)
│       │   │   ├── Strategic Agent Card
│       │   │   │   ├── State: SPEAKING (pulsing border)
│       │   │   │   ├── State: ANALYZING
│       │   │   │   └── State: COMPLETE ✔
│       │   │   ├── Financial Agent Card
│       │   │   └── Conflict Level Indicator
│       │   ├── [ZONE] Center Arena (40%)
│       │   │   ├── Strategic Objective Panel ▼ (collapsed)
│       │   │   ├── Input Lock Alert
│       │   │   ├── Orchestrator Card (Cyan)
│       │   │   ├── Decision Spine (Muted Gold #C6A75E)
│       │   │   ├── Main Intelligence Card (streaming insights)
│       │   │   │   └── Laser Lines (SVG, active agent → card)
│       │   │   └── Critic Agent Panel (Red, bottom)
│       │   ├── [ZONE] Right Intelligence Column (30%)
│       │   │   ├── Consensus Meter
│       │   │   ├── Confidence Score
│       │   │   ├── Decision Stability Index
│       │   │   ├── Key Risk Level
│       │   │   ├── Next Action Forecast
│       │   │   ├── Agent Contribution (4 mini bars)
│       │   │   ├── System Integrity + Latency
│       │   │   └── Collapsed Log Panel
│       │   │       ├── Search bar
│       │   │       ├── [BUTTON] Export Logs
│       │   │       └── Log entries (timestamp + agent + preview, expandable)
│       │   └── [COMPONENT] Footer Telemetry
│       │       └── Elapsed Time | Estimated Completion | Status
│       │
│       └── [SCREEN] Final Report
│           ├── Top Section (20%): 5 Executive Gauges + Key Drivers
│           ├── Document Viewer (Left 75%)
│           │   ├── Tab: Executive Summary
│           │   ├── Tab: Full Report (Markdown)
│           │   ├── Tab: Minority Dissents
│           │   └── Tab: Actionable Steps
│           │       └── Decision Timeline (bottom)
│           └── Action Column (Right 25%)
│               ├── Confidence Trend Sparkline
│               ├── Copy to Clipboard
│               ├── Export as PDF
│               ├── Download Brief (.DOCX)
│               ├── Share to Board
│               └── Authentication Block (agent list + SHA-256)
│
├── SESSION ENGINE
│   ├── Session Initializer
│   │   ├── UUID generator
│   │   ├── Classification detector
│   │   ├── Mode resolver
│   │   ├── Agent roster assembler
│   │   └── Audit pipeline opener
│   ├── Deliberation Runtime
│   │   ├── Round manager
│   │   ├── Speaking queue
│   │   ├── Streaming renderer
│   │   └── Laser animation controller
│   ├── Consensus Engine
│   │   ├── Per-round scorer
│   │   ├── Conflict detector
│   │   ├── Stability index
│   │   └── Convergence threshold
│   └── Report Compiler
│       ├── Summary generator
│       ├── Full report assembler
│       ├── Minority dissent compiler
│       ├── Actionable steps extractor
│       └── Timeline constructor
│
├── AI ORCHESTRATION LAYER
│   ├── Orchestrator Agent (Cyan)
│   ├── Strategic Agent (Emerald)
│   ├── Financial Agent (Purple)
│   ├── Critic Agent (Red)
│   ├── Legal Agent (Amber) [Enterprise+]
│   ├── Risk Agent (Orange) [Enterprise+]
│   ├── Intelligence Agent [Government]
│   └── Policy Agent [Government]
│
├── REPORT ENGINE
│   ├── SDD Generator (Sovereign Decision Document)
│   ├── PDF Exporter
│   ├── DOCX Brief Generator
│   ├── Board Share Module
│   └── Audit Log Renderer
│
├── AUDIT INFRASTRUCTURE
│   ├── Append-only log pipeline
│   ├── SHA-256 hash generator
│   ├── Agent contribution recorder
│   ├── Export event logger
│   └── Audit Trail Viewer (modal)
│
├── SECURITY LAYER
│   ├── Auth Service
│   │   ├── Email (primary)
│   │   └── Google OAuth (secondary)
│   ├── MFA Enforcer
│   │   ├── Government portal (mandatory)
│   │   └── Sensitive actions (API key gen, Confidential sessions)
│   ├── Domain Validator (enterprise: reject public domains)
│   ├── CSRF Token Manager
│   ├── HSTS + TLS Enforcer (min TLS 1.2)
│   └── Session Token Lifecycle
│
├── ACCESS CONTROL
│   ├── Role Registry
│   ├── Permission Matrix Engine
│   ├── Data Classification Enforcer
│   └── Export Restriction Controller
│
└── SOVEREIGN DEPLOYMENT MODULE
    ├── On-Premise Configuration
    ├── Air-Gap Mode (no external API calls)
    ├── Data Residency Declaration
    └── Sovereign Upgrade Pathway


═══════════════════════════════════════════════════════════════
END OF MAJLISYNC INFORMATION ARCHITECTURE BLUEPRINT v1.0
Classification: Internal Engineering Reference
Platform: Majlisync / Shuraa
Version: v1.0
Prepared for: Development Team
═══════════════════════════════════════════════════════════════
```
